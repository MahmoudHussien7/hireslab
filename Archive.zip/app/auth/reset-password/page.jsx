import React from 'react'
import ResetPassForm from '@/components/auth/ResetPassWord';

export default function page() {
  return (
    <div>
      <ResetPassForm/>
      
    </div>
  )
}
