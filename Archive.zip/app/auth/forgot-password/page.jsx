import ForgotPasswordForm from '@/components/auth/ForgotPasswordForm'
import React from 'react'

export default function page() {
  return (
    <div>
      <ForgotPasswordForm/>
    </div>
  )
}
