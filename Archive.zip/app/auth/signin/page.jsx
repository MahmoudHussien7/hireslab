import SignInForm from '@/components/auth/SignInForm'
import React from 'react'

export default function page() {
  return (
    <>
    <SignInForm/>    
    </>
  )
}
