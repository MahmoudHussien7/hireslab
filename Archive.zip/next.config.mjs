/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["storage.googleapis.com", "example.com", "google.com"],
  },
};

export default nextConfig;
